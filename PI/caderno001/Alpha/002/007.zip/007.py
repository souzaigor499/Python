# ex007

preco = 100
desco = 5
nome = "arrroiz"

print('{0:<8} {1:<13} {2:<}'.format('Preço','Desconto(%)','Produto'))
print('{0:<8} {1:<13} {2:<} '.format(preco ,desco ,nome))