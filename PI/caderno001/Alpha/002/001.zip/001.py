nome = input('digite seu primeiro nome ')
snome = input('digite seu segundo nome ')

email = nome + '.' + snome + '@gmail.com'

print(email)