# ex002
nome = 'Igor Souza'
print(nome[2:7])