# ex006
pi = 3.141592

print(f'Aqui vai um exemplo {pi:.4f}')

pi = pi = round(pi, 2)
print(f'Aqui vai um exemplo {pi}')
