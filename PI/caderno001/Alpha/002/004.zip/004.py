# ex004
frase = 'As motos estão para os pedestres assim como os barcos estão para os banhistas'
frase = frase.replace('barcos','jet-skis')
print(frase)