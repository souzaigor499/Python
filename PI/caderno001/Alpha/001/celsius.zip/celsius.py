# ex003
temp = float(input('Digite a temperatura em Celsius '))
f = 32 + (temp * 1.8)
k = 273.15 + temp

print(f'Fahrenheit: {f} Kelvin: {k}')
