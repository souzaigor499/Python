
# ex008
a = int(input('Digite o valor de a '))
b = int(input('Digite o valor de b '))
c = int(input('Digite o valor de c '))
x = int(input('Digite o valor de x '))

resultado = a * (x**2) + b * x + c

print(resultado)